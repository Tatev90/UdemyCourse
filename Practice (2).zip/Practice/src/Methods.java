
public class Methods {

public int ValidateHeader() {
	System.out.println("Header links validated");
	return 2;
}

	}

