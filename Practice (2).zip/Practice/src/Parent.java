public class Parent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//this step prints the output
		/*System.out.println("Hello");
		
		//add 2 numbers 2,3 5 
		
         int a=2;
         int b=3;
         int Sum=a+b;
         System.out.println(Sum);
         System.out.println("Sum is "+ Sum);
         //Sum is 5*/
         
         System.out.println("I navigated to home page");
         
      Methods m=new Methods();
      System.out.println(m.ValidateHeader());
      
      //Classobject.methodname 
      //new is a memory elocation operator
	}

}
