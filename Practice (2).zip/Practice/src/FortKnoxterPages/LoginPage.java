/**
 * 
 */
package FortKnoxterPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * @author TATEV This class will store all the locators and methods of login
 *         page
 */
public class LoginPage {

	WebDriver driver;

	By username = By.id("username");
	By password = By.xpath("//input[@id='password']");
	By signinbutton = By.xpath("//button[@type='submit']");

	public LoginPage(WebDriver driver) {
		
		this.driver = driver;

	}
	
	public void loginToFortKnoxter(String userid, String userpass) {
		driver.findElement(username).sendKeys(userid);
		driver.findElement(password).sendKeys(userpass);
		driver.findElement(signinbutton).click();

	}
	
//	public void typeUsername(){
//		driver.findElement(username).sendKeys("JasonJack");
//		
//	}
//	
//	public void typePassword() {
//		driver.findElement(password).sendKeys("Jason1234");
//	}
//	
//	public void clickOnSigninButton() {
//		driver.findElement(signinbutton).click();
//	}
}

