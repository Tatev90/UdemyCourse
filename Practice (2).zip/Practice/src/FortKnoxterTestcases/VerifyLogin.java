/**
 * 
 */
package FortKnoxterTestcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import FortKnoxterPages.LoginPage;

/**
 * @author TATEV
 *
*/

public class VerifyLogin {

	@Test
	public void verifyLogin() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\TATEV\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://web.fortknoxster.com/");

		// call the loginPage

		LoginPage login = new LoginPage(driver);
		login.loginToFortKnoxter("JasonJack", "Jason1234");
//		login.typeUsername();
//		login.typePassword();
//		login.clickOnSigninButton();
		
		driver.quit();

	}
}
