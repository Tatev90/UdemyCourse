package FortKnoxterTestcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import FortKnoxterPages.LoginPageFactory;
import Helper.BrowserFactory;

public class VerifyLoginFactory {
	
	@Test
	public void checkValidUser() {
		
		//This will launch browser and specific url
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\TATEV\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=BrowserFactory.startBrowser("chrome","https://web.fortknoxster.com/");
		
		//Created page object using page factory
		LoginPageFactory login_page=  PageFactory.initElements(driver,LoginPageFactory.class);
		
		//Call the method
		login_page.login_factory("JasonJack", "Jason1234");
	}

}
